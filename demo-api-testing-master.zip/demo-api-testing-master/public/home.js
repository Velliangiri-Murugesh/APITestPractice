function h1Click() {
    alert('H1 Clicked')
}
